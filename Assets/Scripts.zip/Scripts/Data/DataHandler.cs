using System.IO;
using UnityEngine;

//�N�����Ƀf�[�^��ǂݍ���
//�f�[�^�X�V����Json�`���ŕۑ�

public class DataHandler : MonoBehaviour
{
    public static DataHandler instance_ = null;
    private bool hasInitLoaded = false;

    public OptionData optionData_ = null;
    public StageDatas stageDatas_ = null;

    private void Awake()
    {
        if (!instance_)
        {
            instance_ = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void Start()
    {
        DeleteAllData();
        if (hasInitLoaded) return;

        if (!LoadOptioinData())
            CreateInitOptionData();
        if (!LoadStageDatas())
            CreateInitStageDatas();
    }

    //�I�v�V�����f�[�^�ɂ�BGM��L���ɂ��邩�ǂ����̂ݕۑ�
    public bool LoadOptioinData()
    {
        string datastr = string.Empty; ;
        string pathstr = Application.persistentDataPath + "/optionData.json";
        if (!File.Exists(pathstr))
            return false;

        StreamReader reader = null; 
        reader = new StreamReader(pathstr);
        datastr = reader.ReadToEnd();
        reader.Close();
        optionData_ = JsonUtility.FromJson<OptionData>(datastr);

        return true;
    }

    //�I�v�V�����f�[�^��ۑ�
    public void SaveOptionData()
    {
        StreamWriter writer;

        string jsonstr = JsonUtility.ToJson(optionData_);

        writer = new StreamWriter(Application.persistentDataPath + "/optionData.json", false);
        writer.Write(jsonstr);
        writer.Flush();
        writer.Close();
    }

    public void CreateInitOptionData()
    {
        optionData_ = new OptionData();
        SaveOptionData();
    }

    public bool LoadStageDatas()
    {
        string datastr = string.Empty;
        string pathstr = Application.persistentDataPath + "/stageDatas.json";
        if (!File.Exists(pathstr))
            return false;

        StreamReader reader;
        reader = new StreamReader(pathstr);
        if (reader == null)
            return false;

        datastr = reader.ReadToEnd();
        reader.Close();
        stageDatas_ = JsonUtility.FromJson<StageDatas>(datastr);

        return true;
    }

    public void SaveStageDatas(StageDatas stageDatas)
    {
        StreamWriter writer;

        string jsonstr = JsonUtility.ToJson(stageDatas);

        writer = new StreamWriter(Application.persistentDataPath + "/stageDatas.json", false);
        writer.Write(jsonstr);
        writer.Flush();
        writer.Close();
    }

    public void CreateInitStageDatas()
    {
        int NUM_STAGE = 20;
        stageDatas_ = new StageDatas();
        stageDatas_.stageDataList = new StageData[NUM_STAGE];
        for (int i = 0; i < NUM_STAGE; i++)
        {
            stageDatas_.stageDataList[i] = new StageData(i + 1, false, 0);
        }
        stageDatas_.stageDataList[0].hasUnLocked_ = true;
    }

    public void DeleteAllData()
    {
        string optionpath = Application.persistentDataPath + "optionData.json";
        if (File.Exists(optionpath))
        {
            File.Delete(optionpath);
        }
        string stagedataspath = Application.persistentDataPath + "stageDatas.json";
        if (File.Exists(stagedataspath))
        {
            File.Delete(stagedataspath);
        }
    }
}
